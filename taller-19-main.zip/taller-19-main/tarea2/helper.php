<?php


function render($view) {
    include_once "Views/base.php";
}